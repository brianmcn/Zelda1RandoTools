﻿See the documentation for v1.3 of Z-Tracker online at

https://github.com/brianmcn/Zelda1RandoTools/blob/v1.3/doc/TOC.md

