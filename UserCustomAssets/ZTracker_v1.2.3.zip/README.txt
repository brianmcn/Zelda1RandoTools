﻿See the documentation for v1.2 of Z-Tracker online at

https://github.com/brianmcn/Zelda1RandoTools/blob/v1.2/doc/TOC.md

